import os
import logging
import asyncio
import requests
import json
import hashlib
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler

# ============================================
# 1. НАСТРОЙКИ - ВСТАВЬ СВОИ ДАННЫЕ В .env
# ============================================
# Токены и ID берутся из переменных окружения
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY")
YOUR_TELEGRAM_ID = int(os.getenv("YOUR_TELEGRAM_ID", "0"))

# ============================================
# ЗАЩИТА ОТ ПОДМЕНЫ ID (ХЭШ)
# ============================================
OWNER_ID_HASH = hashlib.sha256(str(YOUR_TELEGRAM_ID).encode()).hexdigest()

def verify_owner_integrity():
    current_hash = hashlib.sha256(str(YOUR_TELEGRAM_ID).encode()).hexdigest()
    if current_hash != OWNER_ID_HASH:
        print("🔴 ОБНАРУЖЕНА ПОПЫТКА ПОДМЕНЫ ID ВЛАДЕЛЬЦА!")
        return False
    return True

if not verify_owner_integrity():
    print("❌ БОТ ЗАБЛОКИРОВАН! ID был изменен!")
    exit(1)

# ============================================
# 2. НАСТРОЙКА ЛОГИРОВАНИЯ
# ============================================
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class OwnerFilter(logging.Filter):
    def filter(self, record):
        return "Владелец" not in record.getMessage()

logger.addFilter(OwnerFilter())

USERS_FILE = "users_data.json"
BLACKLIST_FILE = "blacklist.json"

# ============================================
# 3. ОСНОВНЫЕ ФУНКЦИИ
# ============================================

def is_owner(user_id):
    """Проверяет, является ли пользователь владельцем"""
    return user_id == YOUR_TELEGRAM_ID

def load_users():
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_users(users_data):
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(users_data, f, ensure_ascii=False, indent=2)

def load_blacklist():
    if os.path.exists(BLACKLIST_FILE):
        try:
            with open(BLACKLIST_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return []
    return []

def save_blacklist(blacklist):
    with open(BLACKLIST_FILE, 'w', encoding='utf-8') as f:
        json.dump(blacklist, f, ensure_ascii=False, indent=2)

def is_user_banned(user_id):
    return str(user_id) in load_blacklist()

def save_user(update, action=None):
    """Сохраняет пользователя, НО НЕ СОХРАНЯЕТ ВЛАДЕЛЬЦА"""
    user = update.effective_user
    if not user:
        return
    
    if is_owner(user.id):
        return
    
    if is_user_banned(user.id):
        return
    
    users = load_users()
    uid = str(user.id)
    
    if uid not in users:
        users[uid] = {
            "first_seen": datetime.now().isoformat(),
            "total": 0,
            "urls": 0,
            "files": 0
        }
    
    users[uid].update({
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "last_seen": datetime.now().isoformat(),
        "total": users[uid].get("total", 0) + 1
    })
    
    if action == "url":
        users[uid]["urls"] = users[uid].get("urls", 0) + 1
    elif action == "file":
        users[uid]["files"] = users[uid].get("files", 0) + 1
    
    save_users(users)
    if not is_owner(user.id):
        logger.info(f"👤 {user.first_name} (@{user.username or 'Нет'}) | ID: {user.id}")

async def send_to_owner(context, user, action=None, url=None, filename=None):
    """Отправляет данные владельцу в личку"""
    msg = "🔔 **НОВОЕ ДЕЙСТВИЕ**\n\n"
    msg += f"🆔 **ID:** `{user.id}`\n"
    msg += f"📛 **Юзернейм:** @{user.username}" if user.username else "📛 **Юзернейм:** Нет\n"
    msg += f"👤 **Имя:** {user.first_name or 'Неизвестно'}\n"
    msg += f"👤 **Фамилия:** {user.last_name or 'Не указана'}\n"
    msg += f"🌐 **Язык:** {user.language_code or 'Неизвестен'}\n"
    msg += f"🤖 **Бот:** {'Да' if user.is_bot else 'Нет'}\n"
    
    if user.username:
        msg += f"🔗 **Ссылка:** https://t.me/{user.username}\n"
    
    if action == "url":
        msg += f"\n📌 **Действие:** Проверил ссылку\n"
        msg += f"🔗 **Ссылка:** {url[:100]}{'...' if len(url) > 100 else ''}"
    elif action == "file":
        msg += f"\n📌 **Действие:** Проверил файл\n"
        msg += f"📁 **Файл:** {filename}"
    else:
        msg += f"\n📌 **Действие:** Зашел в бота"
    
    msg += f"\n🕐 **Время:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    try:
        await context.bot.send_message(
            chat_id=YOUR_TELEGRAM_ID,
            text=msg,
            parse_mode='Markdown'
        )
    except:
        pass

# ============================================
# 4. АДМИНСКИЕ КОМАНДЫ
# ============================================

async def admin_ban(update, context):
    user = update.effective_user
    if not is_owner(user.id):
        return
    
    args = context.args
    if not args:
        await update.message.reply_text("❌ /ban 123456789")
        return
    
    user_id = args[0]
    blacklist = load_blacklist()
    
    if user_id in blacklist:
        await update.message.reply_text(f"⚠️ Пользователь {user_id} уже в черном списке.")
        return
    
    blacklist.append(user_id)
    save_blacklist(blacklist)
    await update.message.reply_text(f"✅ Пользователь {user_id} забанен!")

async def admin_unban(update, context):
    user = update.effective_user
    if not is_owner(user.id):
        return
    
    args = context.args
    if not args:
        await update.message.reply_text("❌ /unban 123456789")
        return
    
    user_id = args[0]
    blacklist = load_blacklist()
    
    if user_id not in blacklist:
        await update.message.reply_text(f"⚠️ Пользователь {user_id} не в черном списке.")
        return
    
    blacklist.remove(user_id)
    save_blacklist(blacklist)
    await update.message.reply_text(f"✅ Пользователь {user_id} разбанен!")

async def admin_stats(update, context):
    user = update.effective_user
    if not is_owner(user.id):
        return
    
    users = load_users()
    blacklist = load_blacklist()
    
    total = len(users)
    actions = sum(u.get("total", 0) for u in users.values())
    urls = sum(u.get("urls", 0) for u in users.values())
    files = sum(u.get("files", 0) for u in users.values())
    
    users_list = ""
    for uid, data in list(users.items())[:10]:
        name = data.get("first_name", "Unknown")
        username = data.get("username", "Нет")
        users_list += f"• {name} (@{username}) - ID: {uid}\n"
    
    await update.message.reply_text(
        f"📊 **СТАТИСТИКА**\n\n"
        f"👥 Пользователей: {total}\n"
        f"💬 Действий: {actions}\n"
        f"🔗 Ссылок: {urls}\n"
        f"📁 Файлов: {files}\n"
        f"⛔ В черном списке: {len(blacklist)}\n\n"
        f"📋 **Последние 10 пользователей:**\n{users_list}",
        reply_markup=main_menu()
    )

# ============================================
# 5. КЛАВИАТУРЫ
# ============================================

def main_menu():
    kb = [
        [InlineKeyboardButton("🚀 Старт", callback_data="start")],
        [InlineKeyboardButton("📊 Статистика", callback_data="stats")]
    ]
    return InlineKeyboardMarkup(kb)

def scan_menu():
    kb = [
        [InlineKeyboardButton("🔗 Ссылка", callback_data="url")],
        [InlineKeyboardButton("📁 Файл", callback_data="file")],
        [InlineKeyboardButton("❌ Отмена", callback_data="cancel")]
    ]
    return InlineKeyboardMarkup(kb)

def cancel_btn():
    kb = [[InlineKeyboardButton("❌ Отмена", callback_data="cancel")]]
    return InlineKeyboardMarkup(kb)

def after_scan():
    kb = [
        [InlineKeyboardButton("🔄 Новая ссылка", callback_data="new_url")],
        [InlineKeyboardButton("🔄 Новый файл", callback_data="new_file")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="menu")]
    ]
    return InlineKeyboardMarkup(kb)

# ============================================
# 6. VIRUSTOTAL API
# ============================================

def vt_scan_url(url):
    headers = {"x-apikey": VIRUSTOTAL_API_KEY}
    try:
        r = requests.post("https://www.virustotal.com/api/v3/urls", 
                         headers=headers, data={"url": url}, timeout=30)
        if r.status_code == 200:
            return r.json()['data']['id']
    except:
        pass
    return None

def vt_scan_file(content, name):
    headers = {"x-apikey": VIRUSTOTAL_API_KEY}
    try:
        r = requests.post("https://www.virustotal.com/api/v3/files",
                         headers=headers, files={"file": (name, content)}, timeout=60)
        if r.status_code == 200:
            return r.json()['data']['id']
    except:
        pass
    return None

def vt_get_status(aid):
    headers = {"x-apikey": VIRUSTOTAL_API_KEY}
    try:
        r = requests.get(f"https://www.virustotal.com/api/v3/analyses/{aid}",
                        headers=headers, timeout=30)
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return None

# ============================================
# 7. ОБРАБОТЧИКИ
# ============================================

async def start(update, context):
    user = update.effective_user
    
    if is_user_banned(user.id):
        await update.message.reply_text("⛔ Вы забанены!")
        return
    
    if not is_owner(user.id):
        save_user(update)
        await send_to_owner(context, user)
    
    await update.message.reply_text(
        f"👋 Привет, {user.first_name}!\n\n"
        "Я бот для проверки ссылок и файлов через VirusTotal.\n"
        "Нажми 🚀 Старт, чтобы начать.",
        reply_markup=main_menu()
    )

async def button(update, context):
    query = update.callback_query
    await query.answer()
    data = query.data
    
    user = update.effective_user
    
    if is_user_banned(user.id):
        await query.edit_message_text("⛔ Вы забанены!")
        return
    
    if data == "start":
        await query.edit_message_text("🔍 Выбери, что проверить:", reply_markup=scan_menu())
    elif data == "url":
        context.user_data['type'] = 'url'
        await query.edit_message_text("🔗 Отправь ссылку (http:// или https://)", reply_markup=cancel_btn())
    elif data == "file":
        context.user_data['type'] = 'file'
        await query.edit_message_text("📁 Отправь файл (до 32 МБ)", reply_markup=cancel_btn())
    elif data == "cancel":
        context.user_data.clear()
        await query.edit_message_text("❌ Отменено", reply_markup=main_menu())
    elif data == "new_url":
        context.user_data['type'] = 'url'
        await query.edit_message_text("🔗 Отправь новую ссылку:", reply_markup=cancel_btn())
    elif data == "new_file":
        context.user_data['type'] = 'file'
        await query.edit_message_text("📁 Отправь новый файл:", reply_markup=cancel_btn())
    elif data == "menu":
        context.user_data.clear()
        await query.edit_message_text("🏠 Главное меню", reply_markup=main_menu())
    elif data == "stats":
        users = load_users()
        total = len(users)
        actions = sum(u.get("total", 0) for u in users.values())
        urls = sum(u.get("urls", 0) for u in users.values())
        files = sum(u.get("files", 0) for u in users.values())
        
        await query.edit_message_text(
            f"📊 **Статистика бота**\n\n"
            f"👥 Пользователей: {total}\n"
            f"💬 Действий: {actions}\n"
            f"🔗 Ссылок: {urls}\n"
            f"📁 Файлов: {files}",
            reply_markup=main_menu()
        )

async def handle_message(update, context):
    scan_type = context.user_data.get('type')
    user = update.effective_user
    
    if is_user_banned(user.id):
        await update.message.reply_text("⛔ Вы забанены!")
        return
    
    if not scan_type:
        if not is_owner(user.id):
            save_user(update)
            await send_to_owner(context, user)
        await update.message.reply_text("⚠️ Сначала нажми 'Старт' и выбери тип проверки.", reply_markup=main_menu())
        return
    
    if scan_type == "url":
        url = update.message.text.strip()
        if not url.startswith(("http://", "https://")):
            await update.message.reply_text("⚠️ Это не ссылка! Нужно http:// или https://", reply_markup=cancel_btn())
            return
        
        if not is_owner(user.id):
            save_user(update, "url")
            await send_to_owner(context, user, "url", url)
        
        await update.message.reply_text("🔎 Отправляю ссылку в VirusTotal...")
        aid = vt_scan_url(url)
        if not aid:
            await update.message.reply_text("❌ Ошибка! Проверь API ключ.", reply_markup=main_menu())
            return
        await update.message.reply_text("⏳ Жду результат...")
        for _ in range(24):
            await asyncio.sleep(5)
            data = vt_get_status(aid)
            if data and data.get('data', {}).get('attributes', {}).get('status') == "completed":
                stats = data['data']['attributes']['stats']
                msg = f"🔗 **Результат:**\n\n✅ Безопасно: {stats.get('harmless', 0)}\n⚠️ Подозрительно: {stats.get('suspicious', 0)}\n☣️ Вредоносно: {stats.get('malicious', 0)}\n"
                msg += "⚠️ **ВНИМАНИЕ! Ссылка может быть опасна!**" if stats.get('malicious', 0) > 0 else "✅ **Ссылка безопасна**"
                await update.message.reply_text(msg, reply_markup=after_scan())
                return
        await update.message.reply_text("⏳ Время вышло. Попробуй позже.", reply_markup=main_menu())
    
    elif scan_type == "file":
        if not update.message.document:
            await update.message.reply_text("⚠️ Отправь файл (нажми скрепку 📎)", reply_markup=cancel_btn())
            return
        file = update.message.document
        if file.file_size > 32 * 1024 * 1024:
            await update.message.reply_text("❌ Файл больше 32 МБ!", reply_markup=main_menu())
            return
        
        if not is_owner(user.id):
            save_user(update, "file")
            await send_to_owner(context, user, "file", filename=file.file_name)
        
        await update.message.reply_text("📁 Скачиваю файл...")
        file_obj = await file.get_file()
        content = await file_obj.download_as_bytearray()
        await update.message.reply_text("📤 Отправляю в VirusTotal...")
        aid = vt_scan_file(content, file.file_name)
        if not aid:
            await update.message.reply_text("❌ Ошибка! Проверь API ключ.", reply_markup=main_menu())
            return
        await update.message.reply_text("⏳ Жду результат...")
        for _ in range(24):
            await asyncio.sleep(5)
            data = vt_get_status(aid)
            if data and data.get('data', {}).get('attributes', {}).get('status') == "completed":
                stats = data['data']['attributes']['stats']
                msg = f"📁 **Результат для {file.file_name}:**\n\n✅ Безопасно: {stats.get('harmless', 0)}\n⚠️ Подозрительно: {stats.get('suspicious', 0)}\n☣️ Вредоносно: {stats.get('malicious', 0)}\n"
                msg += "⚠️ **ВНИМАНИЕ! Файл может быть опасен!**" if stats.get('malicious', 0) > 0 else "✅ **Файл безопасен**"
                await update.message.reply_text(msg, reply_markup=after_scan())
                return
        await update.message.reply_text("⏳ Время вышло. Попробуй позже.", reply_markup=main_menu())

# ============================================
# 8. ЗАПУСК
# ============================================

if __name__ == "__main__":
    if not TELEGRAM_TOKEN or TELEGRAM_TOKEN == "ВАШ_ТОКЕН_БОТА":
        print("❌ ОШИБКА: Не задан TELEGRAM_TOKEN!")
        print("📝 Создай файл .env и добавь TELEGRAM_TOKEN=твой_токен")
        exit()
    if not VIRUSTOTAL_API_KEY or VIRUSTOTAL_API_KEY == "ВАШ_API_КЛЮЧ_VIRUSTOTAL":
        print("❌ ОШИБКА: Не задан VIRUSTOTAL_API_KEY!")
        print("📝 Добавь в .env VIRUSTOTAL_API_KEY=твой_ключ")
        exit()
    if YOUR_TELEGRAM_ID == 0:
        print("❌ ОШИБКА: Не задан YOUR_TELEGRAM_ID!")
        print("📝 Добавь в .env YOUR_TELEGRAM_ID=твой_id")
        exit()
    
    print("=" * 60)
    print("🤖 БОТ ЗАПУСКАЕТСЯ...")
    print("📊 Данные о пользователях приходят в личку владельца")
    print("👻 Владелец скрыт (не сохраняется в базу)")
    print("=" * 60)
    
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("ban", admin_ban))
    app.add_handler(CommandHandler("unban", admin_unban))
    app.add_handler(CommandHandler("adminstats", admin_stats))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_message))
    
    print("✅ Бот готов к работе!")
    app.run_polling()